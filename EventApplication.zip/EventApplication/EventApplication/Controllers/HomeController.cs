﻿/*using EventApplication.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
*/
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using EventApplication.Models;

namespace EventApplication.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            /*
             try
            {
                var homes = db.Home.Include(e => e.Event);
                return View(homes.ToList());
            }
            catch (Exception ex)
            {
                return View();
            }              
             */
            return View();
        }
        /*
        public ActionResult LastMinuteDeals()
        {
            var event = GetLastMinuteDeals();
            return PartialView("_LastMinuteDeals")
        }
        */

        /*    
        private Event LastMinuteDeals()
        {
            var event = db.Events.OrderBy(e => System.Guid.NewGuid()).Second();

            return event;
        }
        */
        
        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
        /*
        public ActionResult FindanEvent
        {
            var events = GetEvents(q)

        }
        */
    }
}